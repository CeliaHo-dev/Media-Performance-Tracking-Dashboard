# Assets

The original dashboard screenshot was intentionally not copied into this public portfolio repository because it contains real brand names and performance values. Add an anonymized or synthetic screenshot here before publishing.
