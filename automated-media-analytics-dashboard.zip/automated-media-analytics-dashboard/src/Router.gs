// ============================================================
// Router.gs — Web app router and absolute URL injection
// ============================================================

function doGet(e) {
  let page = 'overview';

  try {
    const requestedPage = e && e.parameter ? e.parameter.page : null;
    if (requestedPage && APP_CONFIG.PAGES.indexOf(requestedPage) > -1) {
      page = requestedPage;
    }
  } catch (error) {
    console.warn('[doGet] Query parameter error:', error);
  }

  try {
    const appUrl = ScriptApp.getService().getUrl();
    let html = HtmlService.createHtmlOutputFromFile(page).getContent();

    // The front end uses this value for page navigation inside the GAS web app.
    const injection = '<script>var GAS_URL = ' + JSON.stringify(appUrl) + ';<\\/script>';
    html = html.replace('</head>', injection + '\n</head>');

    return HtmlService.createHtmlOutput(html)
      .setTitle(APP_CONFIG.APP_TITLE)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
  } catch (error) {
    console.error('[doGet] Failed to load page:', page, error);
    return HtmlService.createHtmlOutput(
      '<div style="padding:40px;background:#0f0f1a;color:#e2e8f0;min-height:100vh;font-family:sans-serif">' +
      '<h2 style="color:#ef4444;margin-bottom:12px">Unable to load this dashboard page.</h2>' +
      '<pre style="background:#1a1a2e;padding:16px;border-radius:8px;color:#94a3b8">' +
      escapeHtml_(String(error)) + '</pre>' +
      '<p style="margin-top:16px"><a href="?page=overview" style="color:#818cf8">Back to Overview</a></p>' +
      '</div>'
    );
  }
}

function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

function escapeHtml_(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
