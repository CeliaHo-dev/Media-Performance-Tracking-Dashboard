// ============================================================
// DemoData.gs — Synthetic data generator for the public repository
// ============================================================

/**
 * Creates small RAW_FB and RAW_TT datasets with fictional brands.
 * This lets reviewers run the portfolio edition without proprietary data.
 */
function setupDemoData() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const demo = getDemoRows_();

  writeDemoSheet_(spreadsheet, APP_CONFIG.SHEETS.FACEBOOK, demo.facebook);
  writeDemoSheet_(spreadsheet, APP_CONFIG.SHEETS.TIKTOK, demo.tiktok);

  incrementCacheVersion_();
  updateTimestamp_();
  console.log('[setupDemoData] Synthetic demo data created.');
}

function writeDemoSheet_(spreadsheet, sheetName, rows) {
  let sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) sheet = spreadsheet.insertSheet(sheetName);
  sheet.clearContents();
  sheet.getRange(1, 1, rows.length, rows[0].length).setValues(rows);
  sheet.setFrozenRows(1);
}

function getDemoRows_() {
  return {
    facebook: [
      ['Brand','Objective Edited','Creative Name','Camp Type','Month','Day','Amount Spent','Impressions','Link Clicks','Post Engagement','ThruPlays','Messaging Conversations Started','Page Likes'],
      ['BRAND_A','Traffic','BRAND_A_VIDEO_01','Always On','Jan','2026-01-08',12500000,1550000,18600,8200,312000,0,0],
      ['BRAND_A','Video Views','BRAND_A_VIDEO_02','Launch','Feb','2026-02-11',14800000,1810000,9800,11300,427000,0,0],
      ['BRAND_B','Engagement','BRAND_B_IMAGE_01','Always On','Mar','2026-03-06',9200000,1260000,7400,19400,72000,0,0],
      ['BRAND_C','Messages','BRAND_C_VIDEO_01','Launch','Mar','2026-03-19',7600000,940000,5100,6100,118000,420,0],
      ['BRAND_B','Page Likes','BRAND_B_IMAGE_02','Always On','Apr','2026-04-09',6900000,870000,3300,5400,44000,0,690]
    ],
    tiktok: [
      ['Brand','Objective Edited','Creative Name','Camp Type','Month','Day','Net cost','Impressions','Clicks','View 6s','View 15s','Paid Follows'],
      ['BRAND_A','Traffic','BRAND_A_VIDEO_03','Always On','Jan','2026-01-10',10800000,1710000,21400,526000,219000,0],
      ['BRAND_A','Video Views','BRAND_A_VIDEO_04','Launch','Feb','2026-02-14',13200000,2050000,10200,710000,338000,0],
      ['BRAND_B','Traffic','BRAND_B_VIDEO_01','Always On','Mar','2026-03-08',8700000,1380000,16900,421000,176000,0],
      ['BRAND_C','Follow','BRAND_C_VIDEO_02','Launch','Mar','2026-03-21',8100000,1190000,7200,355000,149000,930],
      ['BRAND_B','Video Views','BRAND_B_VIDEO_02','Always On','Apr','2026-04-12',7400000,1040000,6100,330000,141000,0]
    ]
  };
}
