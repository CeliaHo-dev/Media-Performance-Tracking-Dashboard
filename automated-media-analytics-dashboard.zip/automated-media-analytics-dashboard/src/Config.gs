// ============================================================
// Config.gs — Public portfolio configuration
// ============================================================

const APP_CONFIG = Object.freeze({
  APP_TITLE: 'Automated Media Analytics Dashboard',
  TIMEZONE: 'Asia/Ho_Chi_Minh',
  CACHE_TTL_SECONDS: 3600,
  REFRESH_INTERVAL_MINUTES: 30,
  SHEETS: Object.freeze({
    FACEBOOK: 'RAW_FB',
    TIKTOK: 'RAW_TT'
  }),
  PAGES: Object.freeze(['overview', 'facebook', 'tiktok'])
});
