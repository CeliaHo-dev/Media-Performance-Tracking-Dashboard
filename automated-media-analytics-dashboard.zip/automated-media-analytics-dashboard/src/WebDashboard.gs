// ============================================================
// WebDashboard.gs — Analytics service, aggregation API, and cache layer
// ============================================================

const FB_COL = {
 BRAND:'Brand', OBJECTIVE:'Objective Edited', CREATIVE:'Creative Name',
 CAMP_TYPE:'Camp Type', MONTH:'Month', DATE:'Day',
 SPEND:'Amount Spent', IMPRESSIONS:'Impressions', CLICKS:'Link Clicks',
 ENGAGEMENT:'Post Engagement', THRUPLAY:'ThruPlays',
 MESSAGES:'Messaging Conversations Started', PAGE_LIKES:'Page Likes'
};
const TT_COL = {
 BRAND:'Brand', OBJECTIVE:'Objective Edited', CREATIVE:'Creative Name',
 CAMP_TYPE:'Camp Type', MONTH:'Month', DATE:'Day',
 SPEND:'Net cost', IMPRESSIONS:'Impressions', CLICKS:'Clicks',
 VIEW_6S:'View 6s', VIEW_15S:'View 15s', PAID_FOLLOWS:'Paid Follows'
};

// ── Core Helpers ─────────────────────────────────────────────
function getSheetData_(sheetName) {
 const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetName);
 if (!sheet) { Logger.log('⚠️ Sheet not found: ' + sheetName); return []; }
 const data = sheet.getDataRange().getValues();
 if (data.length < 2) return [];
 const headers = data[0];
 return data.slice(1)
   .filter(row => row.some(cell => cell !== ''))
   .map(row => { const obj = {}; headers.forEach((h,i) => { obj[h] = row[i]; }); return obj; });
}

function toDateStr_(serial) {
 if (serial instanceof Date)
   return Utilities.formatDate(serial, APP_CONFIG.TIMEZONE, 'yyyy-MM-dd');
 if (typeof serial === 'number' && serial > 40000) {
   const d = new Date((serial - 25569) * 86400 * 1000);
   return Utilities.formatDate(d, APP_CONFIG.TIMEZONE, 'yyyy-MM-dd');
 }
 return String(serial);
}

function n_(val) { const v = parseFloat(val); return isNaN(v) ? 0 : v; }
function r2_(v)  { return Math.round(v * 100) / 100; }

function applyFilters_(data, filters) {
 filters = filters || {};
 return data.filter(row => {
   if (filters.brand     && filters.brand     !== 'ALL' && row['Brand']            !== filters.brand)     return false;
   if (filters.objective && filters.objective !== 'ALL' && row['Objective Edited'] !== filters.objective) return false;
   if (filters.campType  && filters.campType  !== 'ALL' && row['Camp Type']        !== filters.campType)  return false;
   if (filters.month     && filters.month     !== 'ALL' && row['Month']            !== filters.month)     return false;
   if (filters.dateFrom || filters.dateTo) {
     const d = toDateStr_(row['Day']);
     if (filters.dateFrom && d < filters.dateFrom) return false;
     if (filters.dateTo   && d > filters.dateTo)   return false;
   }
   return true;
 });
}

function groupSum_(data, keyCol, sumCols) {
 const map = {};
 data.forEach(row => {
   const k = row[keyCol] || 'Unknown';
   if (!map[k]) { map[k] = { label: k }; sumCols.forEach(c => map[k][c] = 0); }
   sumCols.forEach(c => { map[k][c] += n_(row[c]); });
 });
 return Object.values(map);
}

function getPrevPeriodFilters_(filters) {
 if (!filters.dateFrom || !filters.dateTo) return null;
 const from     = new Date(filters.dateFrom + 'T00:00:00');
 const to       = new Date(filters.dateTo   + 'T00:00:00');
 const diffDays = Math.round((to - from) / 86400000) + 1;
 const prevTo   = new Date(from); prevTo.setDate(prevTo.getDate() - 1);
 const prevFrom = new Date(prevTo); prevFrom.setDate(prevFrom.getDate() - diffDays + 1);
 return Object.assign({}, filters, { dateFrom: toDateStr_(prevFrom), dateTo: toDateStr_(prevTo) });
}

function calcDelta_(current, previous) {
 if (previous === null || previous === undefined || previous === 0) return null;
 return r2_((current - previous) / Math.abs(previous) * 100);
}

// ══════════════════════════════════════════════════════════════
// ── CACHE LAYER ───────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════

/**
* Returns the current cache version.
* Incrementing the version makes all previously generated cache keys stale.
*/
function getCacheVersion_() {
 return PropertiesService.getScriptProperties().getProperty('CACHE_VERSION') || '0';
}

/**
* Increments the cache version when source data changes.
*/
function incrementCacheVersion_() {
 const current = parseInt(getCacheVersion_()) + 1;
 PropertiesService.getScriptProperties().setProperty('CACHE_VERSION', String(current));
 Logger.log('[Cache] Version → ' + current);
 return String(current);
}

/**
* Returns cached JSON for a function/filter combination.
*/
function getCachedData_(fnName, filtersJson) {
 try {
   const version = getCacheVersion_();
   const raw     = fnName + '_v' + version + '_' + (filtersJson || '{}');
   const key     = raw.length > 250 ? raw.substring(0, 250) : raw;
   const cached  = CacheService.getScriptCache().get(key);
   if (cached) {
     Logger.log('[Cache] HIT: ' + fnName + ' v' + version);
   } else {
     Logger.log('[Cache] MISS: ' + fnName + ' v' + version);
   }
   return cached;
 } catch(e) {
   Logger.log('[Cache] GET error: ' + e);
   return null;
 }
}

/**
* Stores serialized response data in cache.
*/
function setCachedData_(fnName, filtersJson, data) {
 try {
   const version = getCacheVersion_();
   const raw     = fnName + '_v' + version + '_' + (filtersJson || '{}');
   const key     = raw.length > 250 ? raw.substring(0, 250) : raw;
   const sizeKB  = Math.round(data.length / 1024 * 10) / 10;
   CacheService.getScriptCache().put(key, data, APP_CONFIG.CACHE_TTL_SECONDS);
   Logger.log('[Cache] STORED: ' + fnName + ' (' + sizeKB + 'KB)');
 } catch(e) {
   // CacheService rejects oversized values; log and continue without caching.
   Logger.log('[Cache] STORE failed (size > 100KB?): ' + e);
 }
}

/**
* Manually invalidates cached responses from the Apps Script editor.
*/
function clearCacheManually() {
 const newVersion = incrementCacheVersion_();
 Logger.log('✅ Cache cleared. New version: ' + newVersion);
 try {
   SpreadsheetApp.getUi().alert('✅ Cache cleared!\nNew version: ' + newVersion);
 } catch(e) { /* UI is unavailable when executed by a trigger. */ }
}

/**
* Logs the current cache version and last refresh timestamp.
*/
function checkCacheStatus() {
 const version = getCacheVersion_();
 const lastUpdated = getLastUpdated();
 Logger.log('=== Cache Status ===');
 Logger.log('Version:      ' + version);
 Logger.log('Last Updated: ' + lastUpdated);
 Logger.log('===================');
}

// ══════════════════════════════════════════════════════════════
// ── PUBLIC API ────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════

// ── PAGE 1: Overview ─────────────────────────────────────────
function getOverviewData(filtersJson) {
 // ✅ Check cache first
 const cached = getCachedData_('overview', filtersJson);
 if (cached) return cached;

 try {
   const filters = filtersJson ? JSON.parse(filtersJson) : {};
   const fb = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.FACEBOOK), filters);
   const tt = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.TIKTOK), filters);

   const fbSpend    = fb.reduce((s,r)=>s+n_(r[FB_COL.SPEND]),0);
   const ttSpend    = tt.reduce((s,r)=>s+n_(r[TT_COL.SPEND]),0);
   const fbImpr     = fb.reduce((s,r)=>s+n_(r[FB_COL.IMPRESSIONS]),0);
   const ttImpr     = tt.reduce((s,r)=>s+n_(r[TT_COL.IMPRESSIONS]),0);
   const fbClicks   = fb.reduce((s,r)=>s+n_(r[FB_COL.CLICKS]),0);
   const ttClicks   = tt.reduce((s,r)=>s+n_(r[TT_COL.CLICKS]),0);
   const fbThruplay = fb.reduce((s,r)=>s+n_(r[FB_COL.THRUPLAY]),0);
   const ttView6s   = tt.reduce((s,r)=>s+n_(r[TT_COL.VIEW_6S]),0);
   const totalSpend  = fbSpend + ttSpend;
   const totalImpr   = fbImpr  + ttImpr;
   const totalClicks = fbClicks + ttClicks;
   const totalCPM    = totalImpr > 0 ? r2_(totalSpend / totalImpr * 1000) : 0;
   const totalCTR    = totalImpr > 0 ? r2_(totalClicks / totalImpr * 100) : 0;
   const fbVTR       = fbImpr > 0 ? r2_(fbThruplay / fbImpr * 100) : 0;
   const ttVTR       = ttImpr > 0 ? r2_(ttView6s / ttImpr * 100) : 0;
   const combinedVTR = totalImpr > 0 ? r2_((fbThruplay + ttView6s) / totalImpr * 100) : 0;

   // Prev period
   let prevKPI = null;
   const prevF = getPrevPeriodFilters_(filters);
   if (prevF) {
     const pFB = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.FACEBOOK), prevF);
     const pTT = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.TIKTOK), prevF);
     const pFBSpend = pFB.reduce((s,r)=>s+n_(r[FB_COL.SPEND]),0);
     const pTTSpend = pTT.reduce((s,r)=>s+n_(r[TT_COL.SPEND]),0);
     const pFBImpr  = pFB.reduce((s,r)=>s+n_(r[FB_COL.IMPRESSIONS]),0);
     const pTTImpr  = pTT.reduce((s,r)=>s+n_(r[TT_COL.IMPRESSIONS]),0);
     const pFBClicks= pFB.reduce((s,r)=>s+n_(r[FB_COL.CLICKS]),0);
     const pTTClicks= pTT.reduce((s,r)=>s+n_(r[TT_COL.CLICKS]),0);
     const pFBThru  = pFB.reduce((s,r)=>s+n_(r[FB_COL.THRUPLAY]),0);
     const pTTV6s   = pTT.reduce((s,r)=>s+n_(r[TT_COL.VIEW_6S]),0);
     const pSpend=pFBSpend+pTTSpend, pImpr=pFBImpr+pTTImpr, pClicks=pFBClicks+pTTClicks;
     prevKPI = {
       totalSpend: pSpend, totalImpr: pImpr,
       totalCPM:   pImpr>0?r2_(pSpend/pImpr*1000):0,
       totalCTR:   pImpr>0?r2_(pClicks/pImpr*100):0,
       combinedVTR:pImpr>0?r2_((pFBThru+pTTV6s)/pImpr*100):0,
       label: prevF.dateFrom + ' → ' + prevF.dateTo
     };
   }

   // Spend by Brand
   const brandMap = {};
   fb.forEach(r=>{ const b=r['Brand'];if(!b)return;if(!brandMap[b])brandMap[b]={brand:b,fb:0,tt:0,total:0};brandMap[b].fb+=n_(r[FB_COL.SPEND]);brandMap[b].total+=n_(r[FB_COL.SPEND]); });
   tt.forEach(r=>{ const b=r['Brand'];if(!b)return;if(!brandMap[b])brandMap[b]={brand:b,fb:0,tt:0,total:0};brandMap[b].tt+=n_(r[TT_COL.SPEND]);brandMap[b].total+=n_(r[TT_COL.SPEND]); });
   const spendByBrand = Object.values(brandMap).sort((a,b)=>b.total-a.total).map(d=>({...d,fb:r2_(d.fb),tt:r2_(d.tt),total:r2_(d.total)}));

   // Daily Trend
   const dayMap = {};
   fb.forEach(r=>{const d=toDateStr_(r[FB_COL.DATE]);if(!dayMap[d])dayMap[d]={date:d,fbSpend:0,ttSpend:0,fbImpr:0,ttImpr:0};dayMap[d].fbSpend+=n_(r[FB_COL.SPEND]);dayMap[d].fbImpr+=n_(r[FB_COL.IMPRESSIONS]);});
   tt.forEach(r=>{const d=toDateStr_(r[TT_COL.DATE]);if(!dayMap[d])dayMap[d]={date:d,fbSpend:0,ttSpend:0,fbImpr:0,ttImpr:0};dayMap[d].ttSpend+=n_(r[TT_COL.SPEND]);dayMap[d].ttImpr+=n_(r[TT_COL.IMPRESSIONS]);});
   const dailyTrend = Object.values(dayMap).sort((a,b)=>a.date.localeCompare(b.date)).map(d=>({...d,totalSpend:r2_(d.fbSpend+d.ttSpend)}));

   // Objective Breakdown
   const objMap = {};
   const initObj = () => ({spend:0,impr:0,clicks:0,engagement:0,thruplay:0,messages:0,pageLikes:0,view6s:0,view15s:0,follows:0});
   fb.forEach(r=>{const k=r['Objective Edited']||'Unknown';if(!objMap[k])objMap[k]={objective:k,...initObj()};objMap[k].spend+=n_(r[FB_COL.SPEND]);objMap[k].impr+=n_(r[FB_COL.IMPRESSIONS]);objMap[k].clicks+=n_(r[FB_COL.CLICKS]);objMap[k].engagement+=n_(r[FB_COL.ENGAGEMENT]);objMap[k].thruplay+=n_(r[FB_COL.THRUPLAY]);objMap[k].messages+=n_(r[FB_COL.MESSAGES]);objMap[k].pageLikes+=n_(r[FB_COL.PAGE_LIKES]);});
   tt.forEach(r=>{const k=r['Objective Edited']||'Unknown';if(!objMap[k])objMap[k]={objective:k,...initObj()};objMap[k].spend+=n_(r[TT_COL.SPEND]);objMap[k].impr+=n_(r[TT_COL.IMPRESSIONS]);objMap[k].clicks+=n_(r[TT_COL.CLICKS]);objMap[k].view6s+=n_(r[TT_COL.VIEW_6S]);objMap[k].view15s+=n_(r[TT_COL.VIEW_15S]);objMap[k].follows+=n_(r[TT_COL.PAID_FOLLOWS]);});
   const objectiveBreakdown = Object.values(objMap).map(o=>{
     const ol=o.objective.toLowerCase();
     let lbl='CPM',val=o.impr>0?r2_(o.spend/o.impr*1000):0,type='vnd';
     if(ol.includes('traffic'))                               {lbl='CPC';      val=o.clicks>0     ?r2_(o.spend/o.clicks):0;     type='vnd';}
     else if(ol.includes('engagement'))                       {lbl='CPE';      val=o.engagement>0 ?r2_(o.spend/o.engagement):0; type='vnd';}
     else if(ol.includes('message'))                          {lbl='Cost/Msg'; val=o.messages>0   ?r2_(o.spend/o.messages):0;   type='vnd';}
     else if(ol.includes('pagelike')||ol.includes('like'))    {lbl='Cost/Like';val=o.pageLikes>0  ?r2_(o.spend/o.pageLikes):0;  type='vnd';}
     else if(ol.includes('follow'))                           {lbl='CPF';      val=o.follows>0    ?r2_(o.spend/o.follows):0;    type='vnd';}
     else if(ol.includes('view')||ol.includes('focus')||ol.includes('vsa')){lbl='VTR';val=o.impr>0?r2_((o.thruplay+o.view6s)/o.impr*100):0;type='pct';}
     return{objective:o.objective,spend:r2_(o.spend),impr:o.impr,cpm:o.impr>0?r2_(o.spend/o.impr*1000):0,ctr:o.impr>0?r2_(o.clicks/o.impr*100):0,primaryLabel:lbl,primaryValue:val,primaryType:type};
   }).sort((a,b)=>b.spend-a.spend);

   const result = JSON.stringify({
     success: true,
     kpi: {
       totalSpend:r2_(totalSpend),totalImpr,totalClicks,totalCPM,totalCTR,
       fbSpend:r2_(fbSpend),ttSpend:r2_(ttSpend),
       fbSharePct:totalSpend>0?r2_(fbSpend/totalSpend*100):0,
       ttSharePct:totalSpend>0?r2_(ttSpend/totalSpend*100):0,
       fbVTR,ttVTR,combinedVTR,
       deltaSpend:  prevKPI?calcDelta_(totalSpend,  prevKPI.totalSpend) :null,
       deltaImpr:   prevKPI?calcDelta_(totalImpr,   prevKPI.totalImpr)  :null,
       deltaCPM:    prevKPI?calcDelta_(totalCPM,    prevKPI.totalCPM)   :null,
       deltaCTR:    prevKPI?calcDelta_(totalCTR,    prevKPI.totalCTR)   :null,
       deltaVTR:    prevKPI?calcDelta_(combinedVTR, prevKPI.combinedVTR):null,
       prevLabel:   prevKPI?prevKPI.label:null
     },
     spendByBrand, dailyTrend,
     platformSplit:[
       {platform:'Facebook',spend:r2_(fbSpend),impressions:fbImpr,clicks:fbClicks},
       {platform:'TikTok',  spend:r2_(ttSpend),impressions:ttImpr,clicks:ttClicks}
     ],
     objectiveBreakdown,
     lastUpdated: getLastUpdated()
   });

   // ✅ Store in cache
   setCachedData_('overview', filtersJson, result);
   return result;

 } catch(err) {
   Logger.log('[getOverviewData] ' + err);
   return JSON.stringify({ success:false, error:err.toString() });
 }
}

// ── PAGE 2: Facebook Detail ───────────────────────────────────
function getFBData(filtersJson) {
 // ✅ Check cache first
 const cached = getCachedData_('fb', filtersJson);
 if (cached) return cached;

 try {
   const filters = filtersJson ? JSON.parse(filtersJson) : {};
   const data = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.FACEBOOK), filters);

   const spend      = data.reduce((s,r)=>s+n_(r[FB_COL.SPEND]),0);
   const impr       = data.reduce((s,r)=>s+n_(r[FB_COL.IMPRESSIONS]),0);
   const clicks     = data.reduce((s,r)=>s+n_(r[FB_COL.CLICKS]),0);
   const engagement = data.reduce((s,r)=>s+n_(r[FB_COL.ENGAGEMENT]),0);
   const thruplay   = data.reduce((s,r)=>s+n_(r[FB_COL.THRUPLAY]),0);
   const messages   = data.reduce((s,r)=>s+n_(r[FB_COL.MESSAGES]),0);
   const pageLikes  = data.reduce((s,r)=>s+n_(r[FB_COL.PAGE_LIKES]),0);

   const cpm             = impr>0       ?r2_(spend/impr*1000)     :0;
   const ctr             = impr>0       ?r2_(clicks/impr*100)     :0;
   const cpc             = clicks>0     ?r2_(spend/clicks)        :0;
   const cpe             = engagement>0 ?r2_(spend/engagement)    :0;
   const vtr             = impr>0       ?r2_(thruplay/impr*100)   :0;
   const er              = impr>0       ?r2_(engagement/impr*100) :0;
   const costPerThruplay = thruplay>0   ?r2_(spend/thruplay)      :0;
   const costPerMessage  = messages>0   ?r2_(spend/messages)      :0;
   const costPerLike     = pageLikes>0  ?r2_(spend/pageLikes)     :0;

   // Prev period
   let prevKPI = null;
   const prevF = getPrevPeriodFilters_(filters);
   if (prevF) {
     const pData       = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.FACEBOOK), prevF);
     const pSpend      = pData.reduce((s,r)=>s+n_(r[FB_COL.SPEND]),0);
     const pImpr       = pData.reduce((s,r)=>s+n_(r[FB_COL.IMPRESSIONS]),0);
     const pClicks     = pData.reduce((s,r)=>s+n_(r[FB_COL.CLICKS]),0);
     const pEngagement = pData.reduce((s,r)=>s+n_(r[FB_COL.ENGAGEMENT]),0);
     const pThruplay   = pData.reduce((s,r)=>s+n_(r[FB_COL.THRUPLAY]),0);
     const pMessages   = pData.reduce((s,r)=>s+n_(r[FB_COL.MESSAGES]),0);
     const pPageLikes  = pData.reduce((s,r)=>s+n_(r[FB_COL.PAGE_LIKES]),0);
     prevKPI = {
       spend:pSpend,impr:pImpr,engagement:pEngagement,thruplay:pThruplay,messages:pMessages,pageLikes:pPageLikes,
       cpm:pImpr>0?r2_(pSpend/pImpr*1000):0,ctr:pImpr>0?r2_(pClicks/pImpr*100):0,
       cpc:pClicks>0?r2_(pSpend/pClicks):0,vtr:pImpr>0?r2_(pThruplay/pImpr*100):0,
       er:pImpr>0?r2_(pEngagement/pImpr*100):0,costPerThruplay:pThruplay>0?r2_(pSpend/pThruplay):0,
       label:prevF.dateFrom+' → '+prevF.dateTo
     };
   }

   const spendByObjective = groupSum_(data,'Objective Edited',[FB_COL.SPEND,FB_COL.IMPRESSIONS,FB_COL.CLICKS])
     .map(d=>({objective:d.label,spend:r2_(d[FB_COL.SPEND]),impr:d[FB_COL.IMPRESSIONS],clicks:d[FB_COL.CLICKS],
       cpm:d[FB_COL.IMPRESSIONS]>0?r2_(d[FB_COL.SPEND]/d[FB_COL.IMPRESSIONS]*1000):0,
       ctr:d[FB_COL.IMPRESSIONS]>0?r2_(d[FB_COL.CLICKS]/d[FB_COL.IMPRESSIONS]*100):0}))
     .sort((a,b)=>b.spend-a.spend);

   const spendByCampType = groupSum_(data,'Camp Type',[FB_COL.SPEND,FB_COL.IMPRESSIONS])
     .map(d=>({campType:d.label,spend:r2_(d[FB_COL.SPEND]),impr:d[FB_COL.IMPRESSIONS]}))
     .sort((a,b)=>b.spend-a.spend);

   const spendByBrand = groupSum_(data,'Brand',[FB_COL.SPEND,FB_COL.IMPRESSIONS,FB_COL.CLICKS,FB_COL.THRUPLAY])
     .map(d=>({brand:d.label,spend:r2_(d[FB_COL.SPEND]),impr:d[FB_COL.IMPRESSIONS],clicks:d[FB_COL.CLICKS],
       cpm:d[FB_COL.IMPRESSIONS]>0?r2_(d[FB_COL.SPEND]/d[FB_COL.IMPRESSIONS]*1000):0,
       vtr:d[FB_COL.IMPRESSIONS]>0?r2_(d[FB_COL.THRUPLAY]/d[FB_COL.IMPRESSIONS]*100):0}))
     .sort((a,b)=>b.spend-a.spend);

const creativePerf = groupSum_(data,'Creative Name',[FB_COL.SPEND,FB_COL.IMPRESSIONS,FB_COL.CLICKS,FB_COL.ENGAGEMENT,FB_COL.THRUPLAY,FB_COL.MESSAGES,FB_COL.PAGE_LIKES])
  .map(d=>({
    creative:   d.label,
    spend:      r2_(d[FB_COL.SPEND]),
    impr:       d[FB_COL.IMPRESSIONS],
    clicks:     d[FB_COL.CLICKS],
    engagement: d[FB_COL.ENGAGEMENT],
    thruplay:   d[FB_COL.THRUPLAY],
    messages:   d[FB_COL.MESSAGES],
    pageLikes:  d[FB_COL.PAGE_LIKES],
    cpm:    d[FB_COL.IMPRESSIONS]>0 ? r2_(d[FB_COL.SPEND]/d[FB_COL.IMPRESSIONS]*1000) : 0,
    ctr:    d[FB_COL.IMPRESSIONS]>0 ? r2_(d[FB_COL.CLICKS]/d[FB_COL.IMPRESSIONS]*100)  : 0,
    cpc:    d[FB_COL.CLICKS]>0      ? r2_(d[FB_COL.SPEND]/d[FB_COL.CLICKS])            : 0,
    cpe:    d[FB_COL.ENGAGEMENT]>0  ? r2_(d[FB_COL.SPEND]/d[FB_COL.ENGAGEMENT])        : 0,
    vtr:    d[FB_COL.IMPRESSIONS]>0 ? r2_(d[FB_COL.THRUPLAY]/d[FB_COL.IMPRESSIONS]*100): 0,
    cpv:    d[FB_COL.THRUPLAY]>0    ? r2_(d[FB_COL.SPEND]/d[FB_COL.THRUPLAY])          : 0,  // ✅ NEW
    er:     d[FB_COL.IMPRESSIONS]>0 ? r2_(d[FB_COL.ENGAGEMENT]/d[FB_COL.IMPRESSIONS]*100):0,
    cpLike: d[FB_COL.PAGE_LIKES]>0  ? r2_(d[FB_COL.SPEND]/d[FB_COL.PAGE_LIKES])        : 0,  // ✅ NEW
    cpMsg:  d[FB_COL.MESSAGES]>0    ? r2_(d[FB_COL.SPEND]/d[FB_COL.MESSAGES])           : 0   // ✅ NEW
  })).sort((a,b)=>b.spend-a.spend);

   const dayMap={};
   data.forEach(r=>{
     const d=toDateStr_(r[FB_COL.DATE]);
     if(!dayMap[d])dayMap[d]={date:d,spend:0,impr:0,clicks:0,thruplay:0,engagement:0,messages:0,pageLikes:0};
     dayMap[d].spend+=n_(r[FB_COL.SPEND]);dayMap[d].impr+=n_(r[FB_COL.IMPRESSIONS]);
     dayMap[d].clicks+=n_(r[FB_COL.CLICKS]);dayMap[d].thruplay+=n_(r[FB_COL.THRUPLAY]);
     dayMap[d].engagement+=n_(r[FB_COL.ENGAGEMENT]);dayMap[d].messages+=n_(r[FB_COL.MESSAGES]);
     dayMap[d].pageLikes+=n_(r[FB_COL.PAGE_LIKES]);
   });
   const dailyTrend=Object.values(dayMap).sort((a,b)=>a.date.localeCompare(b.date));

   const result = JSON.stringify({
     success:true,
     kpi:{
       spend:r2_(spend),impr,clicks,engagement,thruplay,messages,pageLikes,
       cpm,ctr,cpc,cpe,vtr,er,costPerThruplay,costPerMessage,costPerLike,
       deltaSpend:           prevKPI?calcDelta_(spend,          prevKPI.spend)          :null,
       deltaImpr:            prevKPI?calcDelta_(impr,           prevKPI.impr)           :null,
       deltaEngagement:      prevKPI?calcDelta_(engagement,     prevKPI.engagement)     :null,
       deltaThruplay:        prevKPI?calcDelta_(thruplay,       prevKPI.thruplay)       :null,
       deltaMessages:        prevKPI?calcDelta_(messages,       prevKPI.messages)       :null,
       deltaPageLikes:       prevKPI?calcDelta_(pageLikes,      prevKPI.pageLikes)      :null,
       deltaCPM:             prevKPI?calcDelta_(cpm,            prevKPI.cpm)            :null,
       deltaCTR:             prevKPI?calcDelta_(ctr,            prevKPI.ctr)            :null,
       deltaCPC:             prevKPI?calcDelta_(cpc,            prevKPI.cpc)            :null,
       deltaVTR:             prevKPI?calcDelta_(vtr,            prevKPI.vtr)            :null,
       deltaER:              prevKPI?calcDelta_(er,             prevKPI.er)             :null,
       deltaCostPerThruplay: prevKPI?calcDelta_(costPerThruplay,prevKPI.costPerThruplay):null,
       prevSpend:      prevKPI?r2_(prevKPI.spend)     :null,
       prevImpr:       prevKPI?prevKPI.impr           :null,
       prevEngagement: prevKPI?prevKPI.engagement     :null,
       prevThruplay:   prevKPI?prevKPI.thruplay       :null,
       prevMessages:   prevKPI?prevKPI.messages       :null,
       prevCPM:        prevKPI?prevKPI.cpm            :null,
       prevCTR:        prevKPI?prevKPI.ctr            :null,
       prevCPC:        prevKPI?prevKPI.cpc            :null,
       prevVTR:        prevKPI?prevKPI.vtr            :null,
       prevER:         prevKPI?prevKPI.er             :null,
       prevCostPerThruplay:prevKPI?prevKPI.costPerThruplay:null,
       prevLabel:      prevKPI?prevKPI.label          :null
     },
     spendByObjective,spendByCampType,spendByBrand,creativePerf,dailyTrend
   });

   // ✅ Store in cache
   setCachedData_('fb', filtersJson, result);
   return result;

 } catch(err) {
   Logger.log('[getFBData] '+err);
   return JSON.stringify({success:false,error:err.toString()});
 }
}

// ── PAGE 3: TikTok Detail ─────────────────────────────────────
function getTTData(filtersJson) {
 // ✅ Check cache first
 const cached = getCachedData_('tt', filtersJson);
 if (cached) return cached;

 try {
   const filters = filtersJson ? JSON.parse(filtersJson) : {};
   const data = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.TIKTOK), filters);

   const spend   = data.reduce((s,r)=>s+n_(r[TT_COL.SPEND]),0);
   const impr    = data.reduce((s,r)=>s+n_(r[TT_COL.IMPRESSIONS]),0);
   const clicks  = data.reduce((s,r)=>s+n_(r[TT_COL.CLICKS]),0);
   const view6s  = data.reduce((s,r)=>s+n_(r[TT_COL.VIEW_6S]),0);
   const view15s = data.reduce((s,r)=>s+n_(r[TT_COL.VIEW_15S]),0);
   const follows = data.reduce((s,r)=>s+n_(r[TT_COL.PAID_FOLLOWS]),0);

   const cpm         = impr>0    ?r2_(spend/impr*1000)   :0;
   const ctr         = impr>0    ?r2_(clicks/impr*100)   :0;
   const cpc         = clicks>0  ?r2_(spend/clicks)      :0;
   const view6sRate  = impr>0    ?r2_(view6s/impr*100)   :0;
   const view15sRate = impr>0    ?r2_(view15s/impr*100)  :0;
   const cpf         = follows>0 ?r2_(spend/follows)     :0;
   const costPer6s   = view6s>0  ?r2_(spend/view6s)      :0;
   const costPer15s  = view15s>0 ?r2_(spend/view15s)     :0;

   // Prev period
   let prevKPI = null;
   const prevF = getPrevPeriodFilters_(filters);
   if (prevF) {
     const pData    = applyFilters_(getSheetData_(APP_CONFIG.SHEETS.TIKTOK), prevF);
     const pSpend   = pData.reduce((s,r)=>s+n_(r[TT_COL.SPEND]),0);
     const pImpr    = pData.reduce((s,r)=>s+n_(r[TT_COL.IMPRESSIONS]),0);
     const pClicks  = pData.reduce((s,r)=>s+n_(r[TT_COL.CLICKS]),0);
     const pView6s  = pData.reduce((s,r)=>s+n_(r[TT_COL.VIEW_6S]),0);
     const pView15s = pData.reduce((s,r)=>s+n_(r[TT_COL.VIEW_15S]),0);
     const pFollows = pData.reduce((s,r)=>s+n_(r[TT_COL.PAID_FOLLOWS]),0);
     prevKPI = {
       spend:pSpend,impr:pImpr,clicks:pClicks,view6s:pView6s,view15s:pView15s,follows:pFollows,
       cpm:pImpr>0?r2_(pSpend/pImpr*1000):0,ctr:pImpr>0?r2_(pClicks/pImpr*100):0,
       cpc:pClicks>0?r2_(pSpend/pClicks):0,view6sRate:pImpr>0?r2_(pView6s/pImpr*100):0,
       view15sRate:pImpr>0?r2_(pView15s/pImpr*100):0,cpf:pFollows>0?r2_(pSpend/pFollows):0,
       label:prevF.dateFrom+' → '+prevF.dateTo
     };
   }

   const spendByObjective = groupSum_(data,'Objective Edited',[TT_COL.SPEND,TT_COL.IMPRESSIONS,TT_COL.CLICKS])
     .map(d=>({objective:d.label,spend:r2_(d[TT_COL.SPEND]),impr:d[TT_COL.IMPRESSIONS],clicks:d[TT_COL.CLICKS],
       cpm:d[TT_COL.IMPRESSIONS]>0?r2_(d[TT_COL.SPEND]/d[TT_COL.IMPRESSIONS]*1000):0,
       ctr:d[TT_COL.IMPRESSIONS]>0?r2_(d[TT_COL.CLICKS]/d[TT_COL.IMPRESSIONS]*100):0}))
     .sort((a,b)=>b.spend-a.spend);

   const spendByCampType = groupSum_(data,'Camp Type',[TT_COL.SPEND,TT_COL.IMPRESSIONS])
     .map(d=>({campType:d.label,spend:r2_(d[TT_COL.SPEND]),impr:d[TT_COL.IMPRESSIONS]}))
     .sort((a,b)=>b.spend-a.spend);

   const spendByBrand = groupSum_(data,'Brand',[TT_COL.SPEND,TT_COL.IMPRESSIONS,TT_COL.CLICKS,TT_COL.VIEW_6S,TT_COL.PAID_FOLLOWS])
     .map(d=>({brand:d.label,spend:r2_(d[TT_COL.SPEND]),impr:d[TT_COL.IMPRESSIONS],clicks:d[TT_COL.CLICKS],
       cpm:d[TT_COL.IMPRESSIONS]>0?r2_(d[TT_COL.SPEND]/d[TT_COL.IMPRESSIONS]*1000):0,
       view6sRate:d[TT_COL.IMPRESSIONS]>0?r2_(d[TT_COL.VIEW_6S]/d[TT_COL.IMPRESSIONS]*100):0,
       cpf:d[TT_COL.PAID_FOLLOWS]>0?r2_(d[TT_COL.SPEND]/d[TT_COL.PAID_FOLLOWS]):0}))
     .sort((a,b)=>b.spend-a.spend);

   const creativePerf = groupSum_(data,'Creative Name',[TT_COL.SPEND,TT_COL.IMPRESSIONS,TT_COL.CLICKS,TT_COL.VIEW_6S,TT_COL.VIEW_15S,TT_COL.PAID_FOLLOWS])
  .map(d=>({
    creative:    d.label,
    spend:       r2_(d[TT_COL.SPEND]),
    impr:        d[TT_COL.IMPRESSIONS],
    clicks:      d[TT_COL.CLICKS],
    view6s:      d[TT_COL.VIEW_6S],
    view15s:     d[TT_COL.VIEW_15S],
    follows:     d[TT_COL.PAID_FOLLOWS],
    cpm:         d[TT_COL.IMPRESSIONS]>0   ? r2_(d[TT_COL.SPEND]/d[TT_COL.IMPRESSIONS]*1000)  : 0,
    ctr:         d[TT_COL.IMPRESSIONS]>0   ? r2_(d[TT_COL.CLICKS]/d[TT_COL.IMPRESSIONS]*100)   : 0,
    cpc:         d[TT_COL.CLICKS]>0        ? r2_(d[TT_COL.SPEND]/d[TT_COL.CLICKS])             : 0,
    view6sRate:  d[TT_COL.IMPRESSIONS]>0   ? r2_(d[TT_COL.VIEW_6S]/d[TT_COL.IMPRESSIONS]*100)  : 0,
    cp6s:        d[TT_COL.VIEW_6S]>0       ? r2_(d[TT_COL.SPEND]/d[TT_COL.VIEW_6S])            : 0,  // ✅ NEW
    view15sRate: d[TT_COL.IMPRESSIONS]>0   ? r2_(d[TT_COL.VIEW_15S]/d[TT_COL.IMPRESSIONS]*100) : 0,
    cp15s:       d[TT_COL.VIEW_15S]>0      ? r2_(d[TT_COL.SPEND]/d[TT_COL.VIEW_15S])           : 0,  // ✅ NEW
    cpf:         d[TT_COL.PAID_FOLLOWS]>0  ? r2_(d[TT_COL.SPEND]/d[TT_COL.PAID_FOLLOWS])       : 0
  })).sort((a,b)=>b.spend-a.spend);
  
   const dayMap={};
   data.forEach(r=>{
     const d=toDateStr_(r[TT_COL.DATE]);
     if(!dayMap[d])dayMap[d]={date:d,spend:0,impr:0,clicks:0,view6s:0,view15s:0,follows:0};
     dayMap[d].spend+=n_(r[TT_COL.SPEND]);dayMap[d].impr+=n_(r[TT_COL.IMPRESSIONS]);
     dayMap[d].clicks+=n_(r[TT_COL.CLICKS]);dayMap[d].view6s+=n_(r[TT_COL.VIEW_6S]);
     dayMap[d].view15s+=n_(r[TT_COL.VIEW_15S]);dayMap[d].follows+=n_(r[TT_COL.PAID_FOLLOWS]);
   });
   const dailyTrend=Object.values(dayMap).sort((a,b)=>a.date.localeCompare(b.date));

   const result = JSON.stringify({
     success:true,
     kpi:{
       spend:r2_(spend),impr,clicks,view6s,view15s,follows,
       cpm,ctr,cpc,view6sRate,view15sRate,cpf,costPer6s,costPer15s,
       deltaSpend:      prevKPI?calcDelta_(spend,      prevKPI.spend)      :null,
       deltaImpr:       prevKPI?calcDelta_(impr,       prevKPI.impr)       :null,
       deltaClicks:     prevKPI?calcDelta_(clicks,     prevKPI.clicks)     :null,
       deltaView6s:     prevKPI?calcDelta_(view6s,     prevKPI.view6s)     :null,
       deltaView15s:    prevKPI?calcDelta_(view15s,    prevKPI.view15s)    :null,
       deltaFollows:    prevKPI?calcDelta_(follows,    prevKPI.follows)    :null,
       deltaCPM:        prevKPI?calcDelta_(cpm,        prevKPI.cpm)        :null,
       deltaCTR:        prevKPI?calcDelta_(ctr,        prevKPI.ctr)        :null,
       deltaCPC:        prevKPI?calcDelta_(cpc,        prevKPI.cpc)        :null,
       deltaView6sRate: prevKPI?calcDelta_(view6sRate, prevKPI.view6sRate) :null,
       deltaView15sRate:prevKPI?calcDelta_(view15sRate,prevKPI.view15sRate):null,
       deltaCPF:        prevKPI?calcDelta_(cpf,        prevKPI.cpf)        :null,
       prevSpend:      prevKPI?r2_(prevKPI.spend)     :null,
       prevImpr:       prevKPI?prevKPI.impr           :null,
       prevView6s:     prevKPI?prevKPI.view6s         :null,
       prevView15s:    prevKPI?prevKPI.view15s        :null,
       prevFollows:    prevKPI?prevKPI.follows        :null,
       prevCPM:        prevKPI?prevKPI.cpm            :null,
       prevCTR:        prevKPI?prevKPI.ctr            :null,
       prevCPC:        prevKPI?prevKPI.cpc            :null,
       prevView6sRate: prevKPI?prevKPI.view6sRate     :null,
       prevView15sRate:prevKPI?prevKPI.view15sRate    :null,
       prevCPF:        prevKPI?prevKPI.cpf            :null,
       prevLabel:      prevKPI?prevKPI.label          :null
     },
     spendByObjective,spendByCampType,spendByBrand,creativePerf,dailyTrend
   });

   // ✅ Store in cache
   setCachedData_('tt', filtersJson, result);
   return result;

 } catch(err) {
   Logger.log('[getTTData] '+err);
   return JSON.stringify({success:false,error:err.toString()});
 }
}

// ── SHARED ────────────────────────────────────────────────────
function getFilterOptions() {
 // Filter dimensions change less frequently, so reuse the standard cache layer.
 const cached = getCachedData_('filters', '{}');
 if (cached) return cached;

 try {
   const fb=getSheetData_(APP_CONFIG.SHEETS.FACEBOOK), tt=getSheetData_(APP_CONFIG.SHEETS.TIKTOK);
   const uniq = arr => [...new Set(arr)].filter(Boolean).sort();
   const result = JSON.stringify({
     success:true,
     brands:     uniq([...fb.map(r=>r['Brand']),            ...tt.map(r=>r['Brand'])]),
     objectives: uniq([...fb.map(r=>r['Objective Edited']), ...tt.map(r=>r['Objective Edited'])]),
     campTypes:  uniq([...fb.map(r=>r['Camp Type']),        ...tt.map(r=>r['Camp Type'])]),
     months:     uniq([...fb.map(r=>r['Month']),            ...tt.map(r=>r['Month'])])
   });
   setCachedData_('filters', '{}', result);
   return result;
 } catch(err) {
   return JSON.stringify({success:false,error:err.toString()});
 }
}

function getLastUpdated() {
 return PropertiesService.getScriptProperties().getProperty('LAST_UPDATED') || '—';
}
function updateTimestamp_() {
 PropertiesService.getScriptProperties()
   .setProperty('LAST_UPDATED', Utilities.formatDate(new Date(), APP_CONFIG.TIMEZONE, 'dd/MM/yyyy HH:mm'));
}
