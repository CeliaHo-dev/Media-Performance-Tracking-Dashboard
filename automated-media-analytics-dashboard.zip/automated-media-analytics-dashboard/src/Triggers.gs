// ============================================================
// Triggers.gs — Scheduled refresh and cache invalidation
// ============================================================

/**
 * Installs the triggers managed by this project.
 * Existing triggers owned by other functions are left untouched.
 */
function setupTriggers() {
  const managedHandlers = ['scheduledRefresh', 'onDataChange'];

  ScriptApp.getProjectTriggers().forEach(trigger => {
    if (managedHandlers.indexOf(trigger.getHandlerFunction()) > -1) {
      ScriptApp.deleteTrigger(trigger);
    }
  });

  ScriptApp.newTrigger('scheduledRefresh')
    .timeBased()
    .everyMinutes(APP_CONFIG.REFRESH_INTERVAL_MINUTES)
    .create();

  ScriptApp.newTrigger('onDataChange')
    .forSpreadsheet(SpreadsheetApp.getActiveSpreadsheet())
    .onChange()
    .create();

  console.log('[setupTriggers] Managed triggers installed.');
}

/** Invalidates cached responses on a fixed schedule. */
function scheduledRefresh() {
  try {
    const version = incrementCacheVersion_();
    updateTimestamp_();
    console.log('[scheduledRefresh] Cache version:', version);
  } catch (error) {
    console.error('[scheduledRefresh] Failed:', error);
  }
}

/**
 * Invalidates cached responses when the spreadsheet changes.
 * The scheduled trigger remains the fallback for connector/import changes.
 */
function onDataChange(e) {
  try {
    const source = e && e.source ? e.source : SpreadsheetApp.getActiveSpreadsheet();
    const activeSheet = source ? source.getActiveSheet() : null;
    const relevantSheets = [APP_CONFIG.SHEETS.FACEBOOK, APP_CONFIG.SHEETS.TIKTOK];

    if (!activeSheet || relevantSheets.indexOf(activeSheet.getName()) === -1) {
      return;
    }

    const version = incrementCacheVersion_();
    updateTimestamp_();
    console.log('[onDataChange] Invalidated cache after change in:', activeSheet.getName(), 'version:', version);
  } catch (error) {
    console.error('[onDataChange] Failed:', error);
  }
}

function listTriggers() {
  ScriptApp.getProjectTriggers().forEach(trigger => {
    console.log(
      trigger.getHandlerFunction(),
      trigger.getEventType(),
      trigger.getTriggerSourceId()
    );
  });
}
